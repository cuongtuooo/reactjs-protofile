
const AppFooter = () => {
    return (
        <div className="text-center my-3">
            {new Date().getFullYear()} Nguyễn Mạnh Cường <span style={{
                color: "#e25555"
            }}>♥</span>
        </div>
    )
}

export default AppFooter;
