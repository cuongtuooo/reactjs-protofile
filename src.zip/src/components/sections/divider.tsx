import { Container } from "react-bootstrap";

const Divider = () => {
    return (
        <Container>
            <div className="divider" />
        </Container>
    )
}

export default Divider;